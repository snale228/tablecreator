﻿using OfficeOpenXml;
using System.Collections.Generic;
using System.IO;

namespace Table_Creator
{
    public class ExcelHelper
    {
        private ExcelPackage excelPackage;

        public ExcelHelper(string filePath)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            excelPackage = new ExcelPackage(new FileInfo(filePath));
        }

        public List<string> GetWorksheets()
        {
            var worksheets = new List<string>();
            foreach (var worksheet in excelPackage.Workbook.Worksheets)
            {
                worksheets.Add(worksheet.Name);
            }
            return worksheets;
        }

        public void SaveChanges()
        {
            excelPackage.Save();
        }

        public void Dispose()
        {
            excelPackage?.Dispose();
        }
    }
}