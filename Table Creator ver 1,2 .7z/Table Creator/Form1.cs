﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using OfficeOpenXml;
using System.Diagnostics;
namespace Table_Creator
{
    public partial class Form1 : Form
    {
        public static readonly string[] TargetColumns = {
            "Ассамблея знаний", "Предметные олимпиады", "Конференции НОУ",
            "Грани таланта", "Прочие конкурсы", "Балл классного руководителя",
            "Соревнования"
        };

        public const int FirstDataRow = 4;
        public const int SurnameColumn = 2;
        public const int NameColumn = 3;
        public const int FirstScoreColumn = 4;

        public ComboBox comboBoxEvents;
        public DataGridView newDataGridView;

        private Button buttonSelectFile;
        private Button buttonCreateRating;
        private Button buttonSelectSavePath;
        private Button buttonConfirmChanges;
        private Button buttonSaveFile;

        public string path;
        public string selectedEvent;
        public Functions _functions;

        private bool _isSaved = true;
        private bool _programmaticChange = false;
        private Dictionary<string, List<string>> _availableClassesCache;
        private ComboBox comboBoxClasses;
        private const string AvailableLetters = "АБВГДЕЖЗИКЛМНОПРСТ";
        private int _lastEventIndex = -1;
        private bool IsSavingInProgress = false;

        public Form1()
        {
            InitializeComponents();
            this.AutoScroll = true;
            this.AutoScrollMargin = new Size(20, 20); // Отступы для скролла
            this.AutoScrollMinSize = new Size(1300, 900); // Минимальный размер области прокрутки
            LoadInitialData();
            this.FormClosing += Form1_FormClosing;
            this.FormClosed += Form1_FormClosed;

        }


        private void InitializeComponents()
        {
            // Основные настройки формы
            this.Text = "Table Creator";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;
            this.MinimumSize = new Size(800, 600);

            // Рассчитываем доступную область с учетом панели задач
            Rectangle workingArea = Screen.FromControl(this).WorkingArea;
            int panelHeight = SystemInformation.HorizontalScrollBarHeight;

            // Главный контейнер
            TableLayoutPanel mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(10),
                CellBorderStyle = TableLayoutPanelCellBorderStyle.None
            };
            this.Controls.Add(mainLayout);

            // Верхняя панель с кнопками
            FlowLayoutPanel topPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(0, 0, 0, 10)
            };
            mainLayout.Controls.Add(topPanel, 0, 0);

            // Центральная панель с DataGridView
            Panel centerPanel = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(0)
            };
            mainLayout.Controls.Add(centerPanel, 0, 1);

            // Нижняя панель с кнопками
            FlowLayoutPanel bottomPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(0, 10, 0, 0)
            };
            mainLayout.Controls.Add(bottomPanel, 0, 2);

            // Настройка пропорций строк
            mainLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            // Инициализация DataGridView
            newDataGridView = new DataGridView
            {
                Name = "newDataGridView",
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = false,
                ScrollBars = ScrollBars.Both,
                Margin = new Padding(0)
            };
            centerPanel.Controls.Add(newDataGridView);

            // Размеры кнопок
            int buttonWidth = 150;
            int buttonHeight = 30;
            int bigButtonWidth = 200;
            int bigButtonHeight = 50;

            // Кнопки верхней панели
            buttonSelectFile = new Button
            {
                Text = "Выбрать файл",
                Size = new Size(buttonWidth, buttonHeight),
                Margin = new Padding(0, 0, 10, 0)
            };
            topPanel.Controls.Add(buttonSelectFile);

            buttonSelectSavePath = new Button
            {
                Text = "Выбрать папку",
                Size = new Size(buttonWidth, buttonHeight),
                Margin = new Padding(0, 0, 10, 0)
            };
            topPanel.Controls.Add(buttonSelectSavePath);

            comboBoxClasses = new ComboBox
            {
                Name = "comboBoxClasses",
                Size = new Size(buttonWidth, buttonHeight),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Margin = new Padding(0, 0, 10, 0)
            };
            topPanel.Controls.Add(comboBoxClasses);

            comboBoxEvents = new ComboBox
            {
                Name = "comboBoxEvents",
                Size = new Size(buttonWidth * 2, buttonHeight),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            topPanel.Controls.Add(comboBoxEvents);

            // Кнопки нижней панели
            buttonConfirmChanges = new Button
            {
                Text = "Подтвердить изменения",
                Size = new Size(bigButtonWidth, bigButtonHeight),
                Margin = new Padding(0, 0, 10, 0)
            };
            bottomPanel.Controls.Add(buttonConfirmChanges);

            buttonSaveFile = new Button
            {
                Text = "Сохранить",
                Size = new Size(bigButtonWidth, bigButtonHeight),
                Margin = new Padding(0, 0, 10, 0)
            };
            bottomPanel.Controls.Add(buttonSaveFile);

            buttonCreateRating = new Button
            {
                Text = "Ученик года",
                Size = new Size(bigButtonWidth, bigButtonHeight)
            };
            bottomPanel.Controls.Add(buttonCreateRating);

            // Подписка на события
            buttonSelectFile.Click += buttonSelectFile_Click;
            buttonSelectSavePath.Click += buttonSelectSavePath_Click;
            buttonConfirmChanges.Click += buttonConfirmChanges_Click;
            buttonSaveFile.Click += buttonSaveFile_Click;
            buttonCreateRating.Click += ButtonCreateRating_Click;
            comboBoxClasses.SelectedIndexChanged += ComboBoxClasses_SelectedIndexChanged;
            comboBoxEvents.SelectedIndexChanged += ComboBoxEvents_SelectedIndexChanged;
            newDataGridView.KeyDown += DataGridView_KeyDown;
            newDataGridView.CellValueChanged += DataGridView_CellValueChanged;
            newDataGridView.CellEndEdit += DataGridView_CellEndEdit;

            this.Resize += (s, e) =>
            {
                // Корректировка размера с учетом панели задач
                int availableHeight = workingArea.Height - (topPanel.Height + bottomPanel.Height + panelHeight);
                newDataGridView.Height = Math.Max(100, availableHeight);
            };
        }

        private void buttonSelectFile_Click(object sender, EventArgs e)
        {
            try
            {
                // Создаем и настраиваем диалог выбора файла
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Title = "Выберите файл Excel";
                    openFileDialog.Filter = "Excel Files|*.xlsx;*.xls;*.xlsm";
                    openFileDialog.FilterIndex = 1;
                    openFileDialog.RestoreDirectory = true;
                    openFileDialog.CheckFileExists = true;
                    openFileDialog.CheckPathExists = true;

                    // Показываем диалог и проверяем результат
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        // Получаем выбранный путь
                        string selectedFilePath = openFileDialog.FileName;

                        // Проверяем, не пытаемся ли мы открыть тот же файл
                        if (path == selectedFilePath)
                        {
                            MessageBox.Show("Этот файл уже открыт", "Информация",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        // Проверяем доступность файла
                        if (!IsFileAccessible(selectedFilePath))
                        {
                            MessageBox.Show("Файл недоступен для чтения", "Ошибка",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        // Сохраняем путь и загружаем данные
                        path = selectedFilePath;
                        SavePathToJson("Path", path);

                        // Загружаем данные из файла
                        LoadExcelData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выборе файла: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GetAcademicYear()
        {
            int currentYear = DateTime.Now.Year;
            int currentMonth = DateTime.Now.Month;

            // Если август-декабрь, то текущий/следующий год
            if (currentMonth >= 8)
            {
                return $"{currentYear}-{currentYear + 1}"; // Заменяем / на -
            }
            // Если январь-июль, то предыдущий/текущий год
            else
            {
                return $"{currentYear - 1}-{currentYear}"; // Заменяем / на -
            }
        }

        private void ButtonCreateRating_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(path) || !File.Exists(path))
                {
                    MessageBox.Show("Сначала откройте файл с данными!", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string savePath = LoadPathFromJson("SavePath") ??
                                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

                // Создаем папку для рейтинга
                string ratingFolder = Path.Combine(savePath, "Рейтинги");
                Directory.CreateDirectory(ratingFolder);

                // Формируем имя файла
                string academicYear = GetAcademicYear().Replace("/", "-");
                string fileName = $"Ученик года {academicYear}.xlsx";
                string filePath = Path.Combine(ratingFolder, fileName);

                // Создаем Excel файл
                using (var package = new ExcelPackage())
                {
                    var worksheet = package.Workbook.Worksheets.Add("Рейтинг");

                    // Заголовок (A1:D1)
                    worksheet.Cells["A1:D1"].Merge = true;
                    worksheet.Cells["A1"].Value = $"Ученик года - {academicYear.Replace("-", "/")}";
                    worksheet.Cells["A1"].Style.Font.Bold = true;
                    worksheet.Cells["A1"].Style.Font.Size = 14;
                    worksheet.Cells["A1"].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;

                    // Заголовки столбцов (A2:D2)
                    worksheet.Cells["A2"].Value = "Место";
                    worksheet.Cells["B2"].Value = "Класс";  // Класс теперь в столбце B
                    worksheet.Cells["C2"].Value = "Фамилия";
                    worksheet.Cells["D2"].Value = "Имя";
                    worksheet.Cells["E2"].Value = "Балл";   // Балл перемещен в E

                    // Стиль для заголовков
                    using (var range = worksheet.Cells["A2:E2"])
                    {
                        range.Style.Font.Bold = true;
                        range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        range.Style.Fill.BackgroundColor.SetColor(Color.LightGray);
                        ApplyBorders(range);
                    }

                    // Получаем ТОП-20 учеников по баллам из столбца V (22)
                    var topStudents = GetTopStudentsFromAllClasses(path, 20);

                    // Заполняем данные
                    for (int i = 0; i < topStudents.Count; i++)
                    {
                        int row = i + 3;

                        worksheet.Cells[$"A{row}"].Value = i + 1;
                        worksheet.Cells[$"B{row}"].Value = topStudents[i].ClassName; // Класс
                        worksheet.Cells[$"C{row}"].Value = topStudents[i].LastName;  // Фамилия
                        worksheet.Cells[$"D{row}"].Value = topStudents[i].FirstName; // Имя
                        worksheet.Cells[$"E{row}"].Value = topStudents[i].Score;     // Балл

                        // Границы для ячеек A2:E21
                        using (var range = worksheet.Cells[$"A{row}:E{row}"])
                        {
                            ApplyBorders(range);
                        }
                    }

                    // Применяем границы ко всему диапазону
                    using (var range = worksheet.Cells["A2:E21"])
                    {
                        ApplyBorders(range);
                    }

                    // Автоподбор ширины столбцов
                    worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                    // Сохраняем файл
                    package.SaveAs(new FileInfo(filePath));
                }

                MessageBox.Show($"Рейтинг успешно создан:\n{filePath}", "Готово",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании рейтинга:\n{ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ApplyBorders(ExcelRange range)
        {
            range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
        }

        private List<StudentScore> GetTopStudentsFromAllClasses(string filePath, int topCount)
        {
            var allStudents = new List<StudentScore>();

            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                foreach (var worksheet in package.Workbook.Worksheets)
                {
                    // Пропускаем служебные листы (если есть)
                    if (worksheet.Name.Equals("Рейтинг", StringComparison.OrdinalIgnoreCase) ||
                        worksheet.Name.Equals("Settings", StringComparison.OrdinalIgnoreCase))
                        continue;

                    // Новый вариант проверки класса
                    if (!IsClassWorksheet(worksheet.Name))
                    {
                        Console.WriteLine($"Пропускаем лист '{worksheet.Name}' - не похож на класс");
                        continue;
                    }

                    Console.WriteLine($"Обрабатываем класс: {worksheet.Name}");

                    int row = FirstDataRow;
                    while (worksheet.Cells[row, 1].Value != null &&
                           !string.IsNullOrWhiteSpace(worksheet.Cells[row, 1].Text))
                    {
                        string lastName = worksheet.Cells[row, SurnameColumn].Text;
                        string firstName = worksheet.Cells[row, NameColumn].Text;

                        // Получаем баллы из столбца V (22)
                        string scoreText = worksheet.Cells[row, 22].Text;
                        Console.WriteLine($"{worksheet.Name}: {lastName} {firstName} - {scoreText}");

                        if (double.TryParse(scoreText, out double score))
                        {
                            allStudents.Add(new StudentScore
                            {
                                LastName = lastName,
                                FirstName = firstName,
                                Score = score,
                                ClassName = worksheet.Name
                            });
                        }
                        row++;
                    }
                }
            }

            // Дополнительная проверка перед сортировкой
            Console.WriteLine($"Всего найдено учеников: {allStudents.Count}");
            foreach (var student in allStudents.Take(10))
            {
                Console.WriteLine($"{student.ClassName} {student.LastName} - {student.Score}");
            }

            return allStudents
                .OrderByDescending(s => s.Score)
                .Take(topCount)
                .ToList();
        }

        private bool IsClassWorksheet(string worksheetName)
        {
            return worksheetName.Length >= 2 &&
                   char.IsDigit(worksheetName[0]) &&
                   char.IsLetter(worksheetName[^1]);
        }

        private void LoadExcelData()
        {
            try
            {
                if (string.IsNullOrEmpty(path)) return;

                // Инициализируем функции работы с Excel
                _functions = new Functions(this);

                // Загружаем данные
                _functions.LoadDataFromExcel(path, selectedEvent);
                _functions.PopulateComboBox(comboBoxEvents);

                // Загружаем список классов
                CacheAvailableClasses(path);
                LoadGroupedClasses();

                // Выбираем первый класс, если есть
                if (comboBoxClasses.Items.Count > 0)
                {
                    comboBoxClasses.SelectedIndex = 0;
                }

                _isSaved = true;
                UpdateWindowTitle();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private bool IsFileAccessible(string filePath)
        {
            try
            {
                using (FileStream fs = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
    
        private void buttonSelectSavePath_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                fbd.Description = "Выберите папку для сохранения файлов";

                // Загружаем текущий путь если он есть
                string currentSavePath = LoadPathFromJson("SavePath");
                if (!string.IsNullOrEmpty(currentSavePath))
                {
                    fbd.SelectedPath = currentSavePath;
                }

                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    SavePathToJson("SavePath", fbd.SelectedPath);
                    MessageBox.Show($"Папка для сохранения установлена: {fbd.SelectedPath}",
                                  "Настройки",
                                  MessageBoxButtons.OK,
                                  MessageBoxIcon.Information);
                }
            }
        }

        private void InitializeDataGridView()
        {
            newDataGridView = new DataGridView
            {
                Name = "newDataGridView",
                Location = new Point(12, 92),
                Size = new Size(1200, 800),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = false
            };

            _functions.InitializeDataGridViewColumns(); // Вызываем метод для инициализации колонок

            newDataGridView.KeyDown += DataGridView_KeyDown;
            newDataGridView.CellValueChanged += DataGridView_CellValueChanged;
            this.Controls.Add(newDataGridView);
            newDataGridView.Columns[0].ReadOnly = true; // Фамилия
            newDataGridView.Columns[1].ReadOnly = true; // Имя
        }

        private int _lastClassIndex = -1;

        private void ComboBoxClasses_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_programmaticChange || comboBoxClasses.SelectedItem == null ||
                comboBoxClasses.SelectedItem.ToString().StartsWith("---"))
                return;

            // Проверка несохраненных изменений
            if (!_isSaved)
            {
                var dialogResult = MessageBox.Show("У вас есть несохраненные изменения. Сохранить перед переключением класса?",
                                                 "Подтверждение",
                                                 MessageBoxButtons.YesNoCancel,
                                                 MessageBoxIcon.Question);

                if (dialogResult == DialogResult.Cancel)
                {
                    _programmaticChange = true;
                    comboBoxClasses.SelectedIndex = _lastClassIndex;
                    _programmaticChange = false;
                    return;
                }
                else if (dialogResult == DialogResult.Yes)
                {
                    _functions.SaveCurrentChangesToWorksheet();
                    _isSaved = true;
                    UpdateWindowTitle();
                }
            }

            _lastClassIndex = comboBoxClasses.SelectedIndex;
            string selectedClass = comboBoxClasses.SelectedItem.ToString();
            LoadClassData(selectedClass);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_isSaved)
            {
                var dialog = new CustomCloseDialog();
                var result = dialog.ShowDialog();

                switch (result)
                {
                    case DialogResult.Yes:
                        buttonSaveFile_Click(null, null);
                        e.Cancel = !_isSaved;
                        break;
                    case DialogResult.No:
                        break;
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            _functions?.Dispose();
        }

        private void LoadInitialData()
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            path = LoadPathFromJson("Path");

            if (!string.IsNullOrEmpty(path))
            {
                try
                {
                    _functions = new Functions(this);
                    _functions.LoadDataFromExcel(path, selectedEvent);
                    _functions.PopulateComboBox(comboBoxEvents);

                    // Добавлено: загрузка классов при старте
                    CacheAvailableClasses(path);
                    LoadGroupedClasses();

                    _isSaved = true;
                    UpdateWindowTitle();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void SaveChangesToCopy(string newFilePath)
        {
            if (IsSavingInProgress) return;
            IsSavingInProgress = true;

            try
            {
                // Создаем временный файл
                string tempFilePath = Path.GetTempFileName();
                File.Copy(path, tempFilePath, true);

                using (var package = new ExcelPackage(new FileInfo(tempFilePath)))
                {
                    ExcelWorksheet sheet = GetCurrentWorksheet(package);
                    if (sheet == null)
                    {
                        throw new Exception("Лист не найден.");
                    }

                    int[] columns = GetColumnsForEvent(selectedEvent);

                    for (int i = 0; i < newDataGridView.Rows.Count; i++)
                    {
                        if (newDataGridView.Rows[i].IsNewRow) continue;

                        for (int j = 0; j < columns.Length; j++)
                        {
                            if (j < newDataGridView.Columns.Count - 2)
                            {
                                sheet.Cells[i + FirstDataRow, columns[j]].Value =
                                    newDataGridView.Rows[i].Cells[j + 2].Value;
                            }
                        }
                    }

                    package.Save();
                }

                // Заменяем старый файл новым
                if (File.Exists(newFilePath))
                {
                    File.Delete(newFilePath);
                }
                File.Move(tempFilePath, newFilePath);
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при сохранении копии: {ex.Message}");
            }
            finally
            {
                IsSavingInProgress = false;
            }
        }

        private ExcelWorksheet GetCurrentWorksheet(ExcelPackage package)
        {
            if (!string.IsNullOrEmpty(comboBoxClasses.SelectedItem?.ToString()) &&
                !comboBoxClasses.SelectedItem.ToString().StartsWith("---"))
            {
                return package.Workbook.Worksheets[comboBoxClasses.SelectedItem.ToString()];
            }
            return package.Workbook.Worksheets[0];
        }

        private void buttonConfirmChanges_Click(object sender, EventArgs e)
        {
            if (IsSavingInProgress) return;
            IsSavingInProgress = true;

            string currentClass = comboBoxClasses.SelectedItem?.ToString();
            string currentEvent = comboBoxEvents.SelectedItem?.ToString();

            try
            {
                if (string.IsNullOrEmpty(path))
                {
                    MessageBox.Show("Сначала откройте файл!", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string savePath = LoadPathFromJson("SavePath");
                if (string.IsNullOrEmpty(savePath))
                {
                    MessageBox.Show("Пожалуйста, укажите папку для сохранения.", "Ошибка",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Создаем временный файл
                string tempFilePath = Path.GetTempFileName();
                File.Copy(path, tempFilePath, true);

                using (var package = new ExcelPackage(new FileInfo(tempFilePath)))
                {
                    // Получаем текущий лист (выбранный класс)
                    if (string.IsNullOrEmpty(currentClass) || currentClass.StartsWith("---"))
                    {
                        MessageBox.Show("Пожалуйста, выберите класс из списка", "Ошибка",
                                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    var worksheet = package.Workbook.Worksheets[currentClass];
                    if (worksheet == null)
                    {
                        MessageBox.Show($"Лист для класса {currentClass} не найден", "Ошибка",
                                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // 1. Сначала сохраняем изменения из DataGridView
                    SaveDataGridViewToWorksheet(worksheet);

                    // 2. Теперь рассчитываем суммы для всех строк
                    CalculateSumsForWorksheet(worksheet);

                    package.Save();
                }

                string fileName = Path.GetFileName(path);
                string newFilePath = Path.Combine(savePath, fileName);

                if (File.Exists(newFilePath))
                {
                    CreateBackup(newFilePath);
                    File.Delete(newFilePath);
                }

                File.Move(tempFilePath, newFilePath);

                // Обновляем путь
                path = newFilePath;
                SavePathToJson("Path", path);

                // Перезагружаем данные
                _functions?.Dispose();
                _functions = new Functions(this);
                _functions.LoadDataFromExcel(path, selectedEvent);

                // Восстанавливаем выбор
                _programmaticChange = true;
                comboBoxClasses.SelectedItem = currentClass;
                comboBoxEvents.SelectedItem = currentEvent;
                LoadClassData(currentClass);
                _programmaticChange = false;

                _isSaved = true;
                UpdateWindowTitle();
                MessageBox.Show($"Изменения успешно сохранены в файл: {newFilePath}",
                              "Сохранение",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
            finally
            {
                IsSavingInProgress = false;
            }
        }

        private void CalculateSumsForWorksheet(ExcelWorksheet worksheet)
        {
            int row = FirstDataRow;

            // Номера столбцов (нумерация с 1)
            const int columnD = 4;   // D
            const int columnE = 5;   // E
            const int columnF = 6;   // F
            const int columnG = 7;   // G
            const int columnH = 8;   // H
            const int columnU = 21;  // U
            const int columnV = 22;  // V
            const int columnW = 23;  // W

            while (worksheet.Cells[row, 1].Value != null && !string.IsNullOrEmpty(worksheet.Cells[row, 1].Text))
            {
                // 1. Сумма D-G (4-7) в W (23)
                double sumDG = 0;
                for (int col = columnD; col <= columnG; col++)
                {
                    if (double.TryParse(worksheet.Cells[row, col].Text, out double val))
                    {
                        sumDG += val;
                    }
                }
                worksheet.Cells[row, columnW].Value = sumDG;

                // 2. Сумма D-U (4-21) в V (22)
                double sumDU = 0;
                for (int col = columnD; col <= columnU; col++)
                {
                    if (double.TryParse(worksheet.Cells[row, col].Text, out double val))
                    {
                        sumDU += val;
                    }
                }
                worksheet.Cells[row, columnV].Value = sumDU;

                row++;
            }
        }

        private void SaveDataGridViewToWorksheet(ExcelWorksheet worksheet)
        {
            if (worksheet == null || newDataGridView == null) return;

            int[] columns = GetColumnsForEvent(selectedEvent);

            for (int i = 0; i < newDataGridView.Rows.Count; i++)
            {
                if (newDataGridView.Rows[i].IsNewRow) continue;

                for (int j = 0; j < columns.Length; j++)
                {
                    if (j < newDataGridView.Columns.Count - 2)
                    {
                        var cellValue = newDataGridView.Rows[i].Cells[j + 2].Value;
                        worksheet.Cells[i + FirstDataRow, columns[j]].Value = cellValue?.ToString();
                    }
                }
            }
        }
        private void ProcessWorksheet(ExcelWorksheet worksheet)
        {
            int row = FirstDataRow;

            while (worksheet.Cells[row, 1].Value != null && !string.IsNullOrEmpty(worksheet.Cells[row, 1].Text))
            {
                // Сумма столбцов D-E (4-5) записываем в W (23)
                double sumDE = 0;
                if (double.TryParse(worksheet.Cells[row, 4].Text, out double dVal)) sumDE += dVal;
                if (double.TryParse(worksheet.Cells[row, 5].Text, out double eVal)) sumDE += eVal;
                worksheet.Cells[row, 23].Value = sumDE;

                // Сумма столбцов F-U (6-21) записываем в V (22)
                double sumFU = 0;
                for (int col = 6; col <= 21; col++)
                {
                    if (double.TryParse(worksheet.Cells[row, col].Text, out double val))
                    {
                        sumFU += val;
                    }
                }
                worksheet.Cells[row, 22].Value = sumFU;

                row++;
            }
        }

        private void CreateBackup(string filePath)
        {
            try
            {
                string backupDir = Path.Combine(Path.GetDirectoryName(filePath), "Backups");
                Directory.CreateDirectory(backupDir);

                string fileName = Path.GetFileNameWithoutExtension(filePath);
                string extension = Path.GetExtension(filePath);
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string backupPath = Path.Combine(backupDir, $"{fileName}_backup_{timestamp}{extension}");

                File.Copy(filePath, backupPath);

                RotateBackups(backupDir, fileName);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при создании бэкапа: {ex.Message}");
            }
        }

        private void RotateBackups(string backupDir, string fileNameBase)
        {
            try
            {
                string pattern = $"{fileNameBase}_backup_*";
                var backups = Directory.GetFiles(backupDir, pattern)
                                    .OrderByDescending(f => f)
                                    .ToList();

                while (backups.Count > 5)
                {
                    File.Delete(backups.Last());
                    backups.RemoveAt(backups.Count - 1);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при ротации бэкапов: {ex.Message}");
            }
        }

        private void ComboBoxEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_programmaticChange || comboBoxEvents.SelectedItem == null)
                return;

            // Проверяем, есть ли несохраненные изменения
            if (!_isSaved)
            {
                var dialogResult = MessageBox.Show("У вас есть несохраненные изменения. Сохранить перед переключением?",
                                                 "Подтверждение",
                                                 MessageBoxButtons.YesNoCancel,
                                                 MessageBoxIcon.Question);

                if (dialogResult == DialogResult.Cancel)
                {
                    _programmaticChange = true;
                    comboBoxEvents.SelectedIndex = _lastEventIndex;
                    _programmaticChange = false;
                    return;
                }
                else if (dialogResult == DialogResult.Yes)
                {
                    if (_functions.SaveCurrentChangesToWorksheet())
                    {
                        _isSaved = true;
                        UpdateWindowTitle();
                    }
                    else
                    {
                        return; // Не продолжаем, если сохранение не удалось
                    }
                }
            }

            // Сохраняем текущий индекс перед изменением
            _lastEventIndex = comboBoxEvents.SelectedIndex;
            selectedEvent = comboBoxEvents.SelectedItem.ToString();

            try
            {
                UpdateDataGridViewWithScores(selectedEvent);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Восстанавливаем предыдущее значение
                _programmaticChange = true;
                comboBoxEvents.SelectedIndex = _lastEventIndex;
                _programmaticChange = false;
            }
        }

        private Button CreateButton(string text, EventHandler handler, Point location, int width, int height = 30)
        {
            var btn = new Button
            {
                Text = text,
                Location = location,
                Size = new Size(width, height),
                Font = new Font("Microsoft Sans Serif", 9.75F)
            };
            btn.Click += handler;
            this.Controls.Add(btn);
            return btn;
        }

        private void DataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Если мы в режиме редактирования - завершаем его
                if (newDataGridView.IsCurrentCellInEditMode)
                {
                    newDataGridView.EndEdit();
                    e.Handled = true;

                    // Вычисляем текущую ячейку после небольшой задержки
                    BeginInvoke((MethodInvoker)delegate {
                        CalculateCurrentCell();
                        MoveToNextCell();
                    });
                }
                else
                {
                    e.Handled = true;
                    CalculateCurrentCell();
                    MoveToNextCell();
                }
            }
        }

        private void DataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (!_programmaticChange && e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                _isSaved = false;
                UpdateWindowTitle();
            }
        }

        private void CalculateCurrentCell()
        {
            if (newDataGridView.CurrentCell == null) return;

            var cell = newDataGridView.CurrentCell;
            string cellValue = cell.Value?.ToString();

            if (!string.IsNullOrEmpty(cellValue) && IsMathExpression(cellValue))
            {
                try
                {
                    cell.Value = CalculateExpression(cellValue);
                    _isSaved = false;
                    UpdateWindowTitle();
                }
                catch
                {
                    // Оставляем оригинальное значение при ошибке вычисления
                }
            }
        }

        private void MoveToNextCell()
        {
            if (newDataGridView.CurrentCell == null) return;

            int newCol = newDataGridView.CurrentCell.ColumnIndex;
            int newRow = newDataGridView.CurrentCell.RowIndex;

            // Определяем следующую ячейку
            if (newCol < newDataGridView.ColumnCount - 1)
            {
                newCol++;
            }
            else if (newRow < newDataGridView.RowCount - 1)
            {
                newCol = 0;
                newRow++;
            }
            else
            {
                return;
            }

            // Переключаемся на следующую ячейку
            newDataGridView.CurrentCell = newDataGridView[newCol, newRow];

            // Если следующая ячейка read-only - пропускаем ее
            if (newDataGridView.CurrentCell.ReadOnly)
            {
                MoveToNextCell();
            }
        }

        private void DataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // Если редактирование завершено не по Enter (например, клик вне ячейки)
            if (Control.ModifierKeys != Keys.Shift && Control.ModifierKeys != Keys.Control)
            {
                CalculateCurrentCell();
            }
        }

        private bool IsMathExpression(string input)
        {
            return !string.IsNullOrEmpty(input) &&
                  (input.Contains("+") || input.Contains("-") ||
                   input.Contains("*") || input.Contains("/"));
        }

        private string CalculateExpression(string expression)
        {
            try
            {
                expression = expression.Replace(" ", "");
                if (expression.Contains("/0")) return "Error: Division by zero";

                var result = new DataTable().Compute(expression, null);
                return result?.ToString() ?? expression;
            }
            catch
            {
                return expression;
            }
        }

        private void UpdateWindowTitle()
        {
            string fileName = Path.GetFileName(path);
            this.Text = _isSaved ? $"Table Creator - {fileName}"
                                : $"Table Creator - {fileName} *";
        }

        private void SetSavePathItem_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                fbd.Description = "Выберите папку для сохранения файлов";
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    SavePathToJson("SavePath", fbd.SelectedPath);
                    MessageBox.Show($"Папка для сохранения установлена: {fbd.SelectedPath}",
                                  "Настройки",
                                  MessageBoxButtons.OK,
                                  MessageBoxIcon.Information);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var ofd = new OpenFileDialog())
            {
                ofd.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
                ofd.Title = "Выберите файл Excel";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    path = ofd.FileName;
                    SavePathToJson("Path", path);

                    try
                    {
                        CacheAvailableClasses(path);
                        LoadGroupedClasses();

                        _functions = new Functions(this);
                        _functions.LoadDataFromExcel(path, selectedEvent);
                        _functions.PopulateComboBox(comboBoxEvents);

                        if (comboBoxClasses.Items.Count > 0)
                        {
                            comboBoxClasses.SelectedIndex = 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при загрузке файла: {ex.Message}",
                                      "Ошибка",
                                      MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void SwitchToCopyFile(string newFilePath)
        {
            try
            {
                // Сохраняем текущие изменения перед переключением
                if (!_isSaved)
                {
                    SaveChangesToCopy(newFilePath);
                }

                // Переключаемся на копию
                path = newFilePath;
                _functions?.Dispose();
                _functions = new Functions(this);
                _functions.LoadDataFromExcel(path, selectedEvent);

                _isSaved = true;
                UpdateWindowTitle();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переключении на копию: {ex.Message}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void buttonSaveFile_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(path))
                {
                    MessageBox.Show("Сначала откройте файл!", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string savePath = LoadPathFromJson("SavePath");
                if (string.IsNullOrEmpty(savePath))
                {
                    MessageBox.Show("Пожалуйста, укажите папку для сохранения.", "Ошибка",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string newFilePath = Path.Combine(savePath, "Измененный_" + Path.GetFileName(path));

                SaveChangesToCopy(newFilePath);

                _isSaved = true;
                UpdateWindowTitle();
            }
            catch (Exception ex)
            {
                _isSaved = false;
                UpdateWindowTitle();
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateExcelFile(string originalFilePath)
        {
            string savePath = LoadPathFromJson("SavePath");
            if (string.IsNullOrEmpty(savePath))
            {
                MessageBox.Show("Пожалуйста, укажите папку для сохранения.", "Ошибка",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string newFilePath = Path.Combine(savePath, "Измененный_" + Path.GetFileName(originalFilePath));

            try
            {
                // Сохраняем текущие изменения перед экспортом
                _functions.SaveCurrentChanges();

                // Копируем весь файл
                File.Copy(originalFilePath, newFilePath, true);

                // Открываем копию для сохранения изменений
                using (var package = new ExcelPackage(new FileInfo(newFilePath)))
                {
                    ExcelWorksheet sheet;
                    if (!string.IsNullOrEmpty(comboBoxClasses.SelectedItem?.ToString()) &&
                        !comboBoxClasses.SelectedItem.ToString().StartsWith("---"))
                    {
                        sheet = package.Workbook.Worksheets[comboBoxClasses.SelectedItem.ToString()];
                    }
                    else
                    {
                        sheet = package.Workbook.Worksheets[0];
                    }

                    if (sheet == null)
                    {
                        MessageBox.Show("Лист не найден.", "Ошибка",
                                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    int[] columns = GetColumnsForEvent(selectedEvent);

                    for (int i = 0; i < newDataGridView.Rows.Count; i++)
                    {
                        for (int j = 0; j < columns.Length; j++)
                        {
                            if (j < newDataGridView.Columns.Count - 2)
                            {
                                sheet.Cells[i + FirstDataRow, columns[j]].Value =
                                    newDataGridView.Rows[i].Cells[j + 2].Value;
                            }
                        }
                    }

                    package.Save();
                }

                _isSaved = true;
                UpdateWindowTitle();
                MessageBox.Show($"Изменения успешно сохранены в файл: {newFilePath}",
                              "Сохранение",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void SavePathToJson(string name, string path)
        {
            try
            {
                string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string configPath = Path.Combine(appDataPath, "TableCreatorSettings.json");

                JObject config = File.Exists(configPath) ?
                    JObject.Parse(File.ReadAllText(configPath)) :
                    new JObject();

                config[name] = path;
                File.WriteAllText(configPath, config.ToString());
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка сохранения настроек: {ex.Message}");
                MessageBox.Show("Не удалось сохранить настройки пути",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Warning);
            }
        }

        private string LoadPathFromJson(string key)
        {
            try
            {
                string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string configPath = Path.Combine(appDataPath, "TableCreatorSettings.json");

                if (File.Exists(configPath))
                {
                    JObject config = JObject.Parse(File.ReadAllText(configPath));
                    return config[key]?.ToString();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка загрузки настроек: {ex.Message}");
            }
            return null;
        }

        public void UpdateDataGridViewWithScores(string selectedEvent)
        {
            if (_functions?.CurrentWorksheet == null)
                return;

            _programmaticChange = true;
            try
            {
                // Сохраняем текущие значения фамилий и имен
                var savedData = new List<Tuple<string, string>>();
                foreach (DataGridViewRow row in newDataGridView.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        savedData.Add(Tuple.Create(
                            row.Cells[0].Value?.ToString(),
                            row.Cells[1].Value?.ToString()));
                    }
                }

                // Очищаем все колонки кроме фамилии и имени
                while (newDataGridView.Columns.Count > 2)
                {
                    newDataGridView.Columns.RemoveAt(2);
                }

                // Добавляем колонки для текущего мероприятия
                var scoreColumnNames = GetScoreColumnNames(selectedEvent);
                foreach (var columnName in scoreColumnNames)
                {
                    newDataGridView.Columns.Add(columnName, columnName);
                }

                // Загружаем баллы для выбранного мероприятия
                var scores = _functions.GetScoresForEvent(selectedEvent);
                for (int i = 0; i < Math.Min(savedData.Count, scores.Count); i++)
                {
                    // Восстанавливаем фамилию и имя
                    newDataGridView.Rows[i].Cells[0].Value = savedData[i].Item1;
                    newDataGridView.Rows[i].Cells[1].Value = savedData[i].Item2;

                    // Заполняем баллы для текущего мероприятия
                    int[] columns = GetColumnsForEvent(selectedEvent);
                    for (int j = 0; j < columns.Length; j++)
                    {
                        if (j + 2 < newDataGridView.Columns.Count)
                        {
                            int excelCol = columns[j];
                            newDataGridView.Rows[i].Cells[j + 2].Value =
                                _functions.CurrentWorksheet.Cells[i + Form1.FirstDataRow, excelCol].Text;
                        }
                    }
                }
            }
            finally
            {
                _programmaticChange = false;
            }
        }

        public int[] GetColumnsForEvent(string eventName)
        {
            switch (eventName)
            {
                case "Ассамблея знаний":
                    return new int[] { 4, 5, 6, 7 };     // Столбцы D,E,F,G
                case "Предметные олимпиады":
                    return new int[] { 8, 9, 10 };       // Столбцы H,I,J
                case "Конференции НОУ":
                    return new int[] { 11, 12, 13 };     // Столбцы K,L,M
                case "Грани таланта":
                    return new int[] { 14 };             // Столбец N
                case "Прочие конкурсы":
                    return new int[] { 15, 16, 17 };     // Столбцы O,P,Q
                case "Балл классного руководителя":
                    return new int[] { 18 };             // Столбец R
                case "Соревнования":
                    return new int[] { 19, 20, 21 };     // Столбцы S,T,U
                default:
                    throw new Exception("Неизвестное мероприятие");
            }
        }

        private List<string> GetScoreColumnNames(string selectedEvent)
        {
            var worksheet = _functions.CurrentWorksheet;
            var scoreColumnNames = new List<string>();

            if (worksheet == null) return scoreColumnNames;

            switch (selectedEvent)
            {
                case "Ассамблея знаний":
                    for (int i = 0; i < 4; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + i].Text);
                    break;
                case "Предметные олимпиады":
                    for (int i = 0; i < 3; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 4 + i].Text);
                    break;
                case "Конференции НОУ":
                    for (int i = 0; i < 3; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 7 + i].Text);
                    break;
                case "Грани таланта":
                    scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 10].Text);
                    break;
                case "Прочие конкурсы":
                    for (int i = 0; i < 3; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 11 + i].Text);
                    break;
                case "Балл классного руководителя":
                    scoreColumnNames.Add(worksheet.Cells[2, FirstScoreColumn + 14].Text);
                    break;
                case "Соревнования":
                    for (int i = 0; i < 3; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 15 + i].Text);
                    break;
            }

            return scoreColumnNames;
        }

        public bool WorksheetExists(ExcelPackage package, string name)
        {
            if (package == null || string.IsNullOrEmpty(name))
                return false;

            string normalizedSearch = name.Replace(" ", "").ToUpper();
            return package.Workbook.Worksheets.Any(ws =>
                ws.Name.Replace(" ", "").ToUpper() == normalizedSearch);
        }

        private void LoadGroupedClasses()
        {
            comboBoxClasses.Items.Clear();

            if (_availableClassesCache == null || _availableClassesCache.Count == 0)
            {
                MessageBox.Show("Не найдено ни одного класса в формате '5А', '6Б' и т.д.",
                               "Информация",
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Information);
                return;
            }

            // Сортируем классы по возрастанию (5,6,7...11)
            var sortedGrades = _availableClassesCache.Keys.OrderBy(g => int.Parse(g));

            foreach (var grade in sortedGrades)
            {
                // Сортируем буквы в алфавитном порядке
                var sortedClasses = _availableClassesCache[grade]
                    .OrderBy(c => c[1].ToString(), StringComparer.Ordinal);

                // Добавляем разделитель с номером класса
                comboBoxClasses.Items.Add($"--- {grade} класс ---");

                // Добавляем сами классы
                foreach (var className in sortedClasses)
                {
                    comboBoxClasses.Items.Add(className);
                }
            }
        }

        private void CacheAvailableClasses(string filePath)
        {
            _availableClassesCache = new Dictionary<string, List<string>>();

            try
            {
                using (var package = new ExcelPackage(new FileInfo(filePath)))
                {
                    foreach (var worksheet in package.Workbook.Worksheets)
                    {
                        string normalizedName = worksheet.Name.Replace(" ", "").ToUpper();

                        // Пропускаем пустые листы
                        if (worksheet.Dimension == null) continue;

                        // Проверяем формат: цифры (5-11) + буква (А-Т)
                        if (normalizedName.Length >= 2 &&
                            AvailableLetters.Contains(normalizedName.Last().ToString()))
                        {
                            string gradePart = normalizedName.Substring(0, normalizedName.Length - 1);
                            if (int.TryParse(gradePart, out int grade) && grade >= 5 && grade <= 11)
                            {
                                string gradeStr = grade.ToString();
                                string className = worksheet.Name; // Сохраняем оригинальное имя листа

                                if (!_availableClassesCache.ContainsKey(gradeStr))
                                {
                                    _availableClassesCache[gradeStr] = new List<string>();
                                }

                                if (!_availableClassesCache[gradeStr].Contains(className))
                                {
                                    _availableClassesCache[gradeStr].Add(className);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при анализе листов: {ex.Message}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void LoadClassData(string className)
        {
            try
            {
                if (string.IsNullOrEmpty(path))
                {
                    MessageBox.Show("Сначала откройте файл!", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _functions.LoadDataFromExcel(path, selectedEvent, className);

                if (!string.IsNullOrEmpty(selectedEvent))
                {
                    UpdateDataGridViewWithScores(selectedEvent);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных класса: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AboutItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Table Creator\nВерсия 1.0\n\nПрограмма для работы с таблицами рейтингов учащихся.",
                           "О программе",
                           MessageBoxButtons.OK,
                           MessageBoxIcon.Information);
        }
    }
    public class StudentScore
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public double Score { get; set; }
        public string ClassName { get; set; }
    }
    public class CustomCloseDialog : Form
    {
        public CustomCloseDialog()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Подтверждение закрытия";
            this.Size = new Size(350, 180);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.ControlBox = false;

            var message = new Label
            {
                Text = "Вы не сохранили файл. Выберите действие:",
                Location = new Point(20, 20),
                AutoSize = true
            };

            var saveButton = new Button
            {
                Text = "Сохранить и выйти",
                DialogResult = DialogResult.Yes,
                Location = new Point(20, 60),
                Size = new Size(120, 30)
            };

            var noSaveButton = new Button
            {
                Text = "Выйти без сохранения",
                DialogResult = DialogResult.No,
                Location = new Point(160, 60),
                Size = new Size(150, 30)
            };

            var cancelButton = new Button
            {
                Text = "Отменить",
                DialogResult = DialogResult.Cancel,
                Location = new Point(20, 100),
                Size = new Size(290, 30)
            };

            this.Controls.Add(message);
            this.Controls.Add(saveButton);
            this.Controls.Add(noSaveButton);
            this.Controls.Add(cancelButton);
        }
    }
}