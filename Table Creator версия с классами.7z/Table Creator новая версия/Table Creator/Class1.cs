﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using DocumentFormat.OpenXml.Spreadsheet;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OfficeOpenXml;
using Table_Creator;

public class Functions : IDisposable
{
    public readonly Form1 _form1;
    public ExcelWorksheet CurrentWorksheet { get; private set; }
    private ExcelPackage _package;
    private bool _disposed = false;

    public Functions(Form1 form1)
    {
        _form1 = form1 ?? throw new ArgumentNullException(nameof(form1));
    }

    public void SaveCurrentChanges()
    {
        if (CurrentWorksheet == null) return;

        try
        {
            int[] columns = _form1.GetColumnsForEvent(_form1.selectedEvent);
            for (int i = 0; i < _form1.newDataGridView.Rows.Count; i++)
            {
                for (int j = 0; j < columns.Length; j++)
                {
                    if (j < _form1.newDataGridView.Columns.Count - 2)
                    {
                        CurrentWorksheet.Cells[i + Form1.FirstDataRow, columns[j]].Value =
                            _form1.newDataGridView.Rows[i].Cells[j + 2].Value;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка при сохранении изменений: {ex.Message}");
        }
    }

    public void LoadDataFromExcel(string filePath, string selectedEvent, string selectedClass = null)
    {
        if (!File.Exists(filePath))
        {
            MessageBox.Show("Файл не найден: " + filePath);
            return;
        }

        try
        {
            _package?.Dispose();
            _package = new ExcelPackage(new FileInfo(filePath));

            if (!string.IsNullOrEmpty(selectedClass) && !_form1.WorksheetExists(_package, selectedClass))
            {
                MessageBox.Show($"Лист '{selectedClass}' не найден в файле");
                return;
            }

            CurrentWorksheet = !string.IsNullOrEmpty(selectedClass)
                ? _package.Workbook.Worksheets[selectedClass]
                : _package.Workbook.Worksheets[0];

            if (CurrentWorksheet == null || CurrentWorksheet.Dimension == null)
            {
                MessageBox.Show($"Лист '{selectedClass ?? "первый лист"}' не найден или пуст");
                return;
            }

            // Убираем Invoke, так как метод вызывается из UI-потока
            InitializeDataGridViewColumns();
            _form1.newDataGridView.Rows.Clear();

            int rowCount = CurrentWorksheet.Dimension.Rows;
            for (int row = Form1.FirstDataRow; row <= rowCount; row++)
            {
                string surname = CurrentWorksheet.Cells[row, Form1.SurnameColumn].Text;
                string name = CurrentWorksheet.Cells[row, Form1.NameColumn].Text;

                if (string.IsNullOrEmpty(surname)) continue;

                _form1.newDataGridView.Rows.Add(surname, name);
            }

            if (!string.IsNullOrEmpty(selectedEvent))
            {
                _form1.UpdateDataGridViewWithScores(selectedEvent);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при загрузке данных из Excel: " + ex.Message);
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposed)
        {
            if (disposing)
            {
                _package?.Dispose();
            }
            _disposed = true;
        }
    }

    public void InitializeDataGridViewColumns()
    {
        _form1.newDataGridView.Columns.Clear();

        _form1.newDataGridView.Columns.Add(new DataGridViewTextBoxColumn
        {
            HeaderText = "Фамилия",
            DataPropertyName = "surname",
            Width = 150,
            ReadOnly = true // Запрещаем редактирование фамилии
        });

        _form1.newDataGridView.Columns.Add(new DataGridViewTextBoxColumn
        {
            HeaderText = "Имя",
            DataPropertyName = "name",
            Width = 150,
            ReadOnly = true // Запрещаем редактирование имени
        });
    }
    public void PopulateComboBox(ComboBox comboBox)
    {
        comboBox.Items.Clear();
        foreach (var item in Form1.TargetColumns)
        {
            comboBox.Items.Add(item);
        }
    }

    public List<string[]> GetScoresForEvent(string eventName)
    {
        var scores = new List<string[]>();
        if (CurrentWorksheet == null) return scores;

        int[] columns = _form1.GetColumnsForEvent(eventName);
        int rowCount = CurrentWorksheet.Dimension.Rows;

        for (int row = Form1.FirstDataRow; row <= rowCount; row++)
        {
            string surname = CurrentWorksheet.Cells[row, Form1.SurnameColumn].Text;
            string name = CurrentWorksheet.Cells[row, Form1.NameColumn].Text;

            if (string.IsNullOrEmpty(surname)) continue;

            var scoreValues = new List<string>();
            foreach (int col in columns)
            {
                scoreValues.Add(CurrentWorksheet.Cells[row, col].Text);
            }

            scores.Add(new[] { surname, name }.Concat(scoreValues).ToArray());
        }

        return scores;
    }

    public bool SaveCurrentChangesToWorksheet()
    {
        if (CurrentWorksheet == null || _package == null)
        {
            MessageBox.Show("Нет активного листа для сохранения", "Ошибка",
                          MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }

        try
        {
            int[] columns = _form1.GetColumnsForEvent(_form1.selectedEvent);

            for (int i = 0; i < _form1.newDataGridView.Rows.Count; i++)
            {
                if (_form1.newDataGridView.Rows[i].IsNewRow) continue;

                for (int j = 0; j < columns.Length; j++)
                {
                    if (j < _form1.newDataGridView.Columns.Count - 2) // -2 потому что первые 2 колонки - Фамилия и Имя
                    {
                        var cellValue = _form1.newDataGridView.Rows[i].Cells[j + 2].Value; // +2 чтобы пропустить Фамилию и Имя
                        CurrentWorksheet.Cells[i + Form1.FirstDataRow, columns[j]].Value = cellValue?.ToString();
                    }
                }
            }

            _package.Save();
            return true;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка при сохранении: {ex.Message}",
                          "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }
}
