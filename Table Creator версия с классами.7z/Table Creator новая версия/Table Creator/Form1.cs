﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using OfficeOpenXml;
namespace Table_Creator
{
    public partial class Form1 : Form
    {
        public static readonly string[] TargetColumns = {
            "Ассамблея знаний", "Предметные олимпиады", "Конференции НОУ",
            "Грани таланта", "Прочие конкурсы", "Балл классного руководителя",
            "Соревнования"
        };

        public const int FirstDataRow = 4;
        public const int SurnameColumn = 2;
        public const int NameColumn = 3;
        public const int FirstScoreColumn = 4;

        public ComboBox comboBoxEvents;
        public DataGridView newDataGridView;
        public Button buttonConfirmChanges, buttonSaveFile, buttonSelectFile;

        public string path;
        public string selectedEvent;
        public Functions _functions;

        private bool _isSaved = true;
        private bool _programmaticChange = false;
        private Dictionary<string, List<string>> _availableClassesCache;
        private ComboBox comboBoxClasses;
        private const string AvailableLetters = "АБВГДЕЖЗИКЛМНОПРСТ";
        private int _lastEventIndex = -1;

        public Form1()
        {
            InitializeComponent();
            InitializeComponents();
            LoadInitialData();
            this.FormClosing += Form1_FormClosing;
            this.FormClosed += Form1_FormClosed;
        }

        private void InitializeComponents()
        {
            this.Text = "Table Creator";
            this.Size = new Size(1500, 1000);
            this.StartPosition = FormStartPosition.CenterScreen;
            
            InitializeMenuStrip();

            newDataGridView = new DataGridView
            {
                Name = "newDataGridView",
                Location = new Point(12, 92),
                Size = new Size(1200, 800),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = false
            };
            newDataGridView.KeyDown += DataGridView_KeyDown;
            newDataGridView.CellValueChanged += DataGridView_CellValueChanged;
            this.Controls.Add(newDataGridView);

            comboBoxEvents = new ComboBox
            {
                Name = "comboBoxEvents",
                Location = new Point(447, 63),
                Size = new Size(300, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            this.Controls.Add(comboBoxEvents);

            buttonSelectFile = CreateButton("Выбрать файл Excel", button1_Click, new Point(12, 12), 150);
            buttonConfirmChanges = CreateButton("Подтвердить изменения", buttonConfirmChanges_Click, new Point(12, 900), 200, 50);
            buttonSaveFile = CreateButton("Сохранить", buttonSaveFile_Click, new Point(218, 900), 200, 50);

            comboBoxEvents.SelectedIndexChanged += ComboBoxEvents_SelectedIndexChanged;

            comboBoxClasses = new ComboBox
            {
                Name = "comboBoxClasses",
                Location = new System.Drawing.Point(447, 23),
                Size = new System.Drawing.Size(100, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            this.Controls.Add(comboBoxClasses);
            comboBoxClasses.SelectedIndexChanged += ComboBoxClasses_SelectedIndexChanged;

            comboBoxEvents.SelectedIndexChanged += ComboBoxEvents_SelectedIndexChanged;
        }

        private void InitializeDataGridView()
        {
            newDataGridView = new DataGridView
            {
                Name = "newDataGridView",
                Location = new Point(12, 92),
                Size = new Size(1200, 800),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = false
            };

            _functions.InitializeDataGridViewColumns(); // Вызываем метод для инициализации колонок

            newDataGridView.KeyDown += DataGridView_KeyDown;
            newDataGridView.CellValueChanged += DataGridView_CellValueChanged;
            this.Controls.Add(newDataGridView);
        }

        private int _lastClassIndex = -1;

        private void ComboBoxClasses_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_programmaticChange || comboBoxClasses.SelectedItem == null ||
                comboBoxClasses.SelectedItem.ToString().StartsWith("---"))
                return;

            // Проверка несохраненных изменений
            if (!_isSaved)
            {
                var dialogResult = MessageBox.Show("У вас есть несохраненные изменения. Сохранить перед переключением класса?",
                                                 "Подтверждение",
                                                 MessageBoxButtons.YesNoCancel,
                                                 MessageBoxIcon.Question);

                if (dialogResult == DialogResult.Cancel)
                {
                    _programmaticChange = true;
                    comboBoxClasses.SelectedIndex = _lastClassIndex;
                    _programmaticChange = false;
                    return;
                }
                else if (dialogResult == DialogResult.Yes)
                {
                    _functions.SaveCurrentChangesToWorksheet();
                    _isSaved = true;
                    UpdateWindowTitle();
                }
            }

            _lastClassIndex = comboBoxClasses.SelectedIndex;
            string selectedClass = comboBoxClasses.SelectedItem.ToString();
            LoadClassData(selectedClass);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_isSaved)
            {
                var dialog = new CustomCloseDialog();
                var result = dialog.ShowDialog();

                switch (result)
                {
                    case DialogResult.Yes:
                        buttonSaveFile_Click(null, null);
                        e.Cancel = !_isSaved;
                        break;
                    case DialogResult.No:
                        break;
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            _functions?.Dispose();
        }

        private void LoadInitialData()
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            path = LoadPathFromJson("Path");

            if (!string.IsNullOrEmpty(path))
            {
                try
                {
                    _functions = new Functions(this);
                    _functions.LoadDataFromExcel(path, selectedEvent);
                    _functions.PopulateComboBox(comboBoxEvents);

                    // Добавлено: загрузка классов при старте
                    CacheAvailableClasses(path);
                    LoadGroupedClasses();

                    _isSaved = true;
                    UpdateWindowTitle();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void SaveChangesToCopy(string newFilePath)
        {
            // Создаем копию файла
            File.Copy(path, newFilePath, true);

            using (var package = new ExcelPackage(new FileInfo(newFilePath)))
            {
                ExcelWorksheet sheet;
                if (!string.IsNullOrEmpty(comboBoxClasses.SelectedItem?.ToString()) &&
                    !comboBoxClasses.SelectedItem.ToString().StartsWith("---"))
                {
                    sheet = package.Workbook.Worksheets[comboBoxClasses.SelectedItem.ToString()];
                }
                else
                {
                    sheet = package.Workbook.Worksheets[0];
                }

                if (sheet == null)
                {
                    throw new Exception("Лист не найден.");
                }

                int[] columns = GetColumnsForEvent(selectedEvent);

                for (int i = 0; i < newDataGridView.Rows.Count; i++)
                {
                    if (newDataGridView.Rows[i].IsNewRow) continue;

                    for (int j = 0; j < columns.Length; j++)
                    {
                        if (j < newDataGridView.Columns.Count - 2)
                        {
                            sheet.Cells[i + FirstDataRow, columns[j]].Value =
                                newDataGridView.Rows[i].Cells[j + 2].Value;
                        }
                    }
                }

                package.Save();
            }
        }

        private void buttonConfirmChanges_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(path))
                {
                    MessageBox.Show("Сначала откройте файл!", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string savePath = LoadPathFromJson("SavePath");
                if (string.IsNullOrEmpty(savePath))
                {
                    MessageBox.Show("Пожалуйста, укажите папку для сохранения.", "Ошибка",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string newFilePath = Path.Combine(savePath, "Измененный_" + Path.GetFileName(path));

                // Сохраняем изменения только в копию
                SaveChangesToCopy(newFilePath);

                _isSaved = true;
                UpdateWindowTitle();
                MessageBox.Show($"Изменения успешно сохранены в файл: {newFilePath}",
                              "Сохранение",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void ComboBoxEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_programmaticChange || comboBoxEvents.SelectedItem == null)
                return;

            // Проверяем, есть ли несохраненные изменения
            if (!_isSaved)
            {
                var dialogResult = MessageBox.Show("У вас есть несохраненные изменения. Сохранить перед переключением?",
                                                 "Подтверждение",
                                                 MessageBoxButtons.YesNoCancel,
                                                 MessageBoxIcon.Question);

                if (dialogResult == DialogResult.Cancel)
                {
                    _programmaticChange = true;
                    comboBoxEvents.SelectedIndex = _lastEventIndex;
                    _programmaticChange = false;
                    return;
                }
                else if (dialogResult == DialogResult.Yes)
                {
                    if (_functions.SaveCurrentChangesToWorksheet())
                    {
                        _isSaved = true;
                        UpdateWindowTitle();
                    }
                    else
                    {
                        return; // Не продолжаем, если сохранение не удалось
                    }
                }
            }

            // Сохраняем текущий индекс перед изменением
            _lastEventIndex = comboBoxEvents.SelectedIndex;
            selectedEvent = comboBoxEvents.SelectedItem.ToString();

            try
            {
                UpdateDataGridViewWithScores(selectedEvent);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Восстанавливаем предыдущее значение
                _programmaticChange = true;
                comboBoxEvents.SelectedIndex = _lastEventIndex;
                _programmaticChange = false;
            }
        }

        private Button CreateButton(string text, EventHandler handler, Point location, int width, int height = 30)
        {
            var btn = new Button
            {
                Text = text,
                Location = location,
                Size = new Size(width, height),
                Font = new Font("Microsoft Sans Serif", 9.75F)
            };
            btn.Click += handler;
            this.Controls.Add(btn);
            return btn;
        }

        private void DataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                CalculateCurrentCell();
                MoveToNextCell();
            }
        }

        private void DataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (!_programmaticChange && e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                _isSaved = false;
                UpdateWindowTitle();
            }
        }

        private void CalculateCurrentCell()
        {
            if (newDataGridView.CurrentCell == null) return;

            var cell = newDataGridView.CurrentCell;
            if (cell.Value != null && IsMathExpression(cell.Value.ToString()))
            {
                cell.Value = CalculateExpression(cell.Value.ToString());
                _isSaved = false;
                UpdateWindowTitle();
            }
        }

        private void MoveToNextCell()
        {
            int col = newDataGridView.CurrentCell.ColumnIndex;
            int row = newDataGridView.CurrentCell.RowIndex;

            if (col < newDataGridView.ColumnCount - 1)
            {
                newDataGridView.CurrentCell = newDataGridView[col + 1, row];
            }
            else if (row < newDataGridView.RowCount - 1)
            {
                newDataGridView.CurrentCell = newDataGridView[0, row + 1];
            }
        }

        private bool IsMathExpression(string input)
        {
            return !string.IsNullOrEmpty(input) &&
                  (input.Contains("+") || input.Contains("-") ||
                   input.Contains("*") || input.Contains("/"));
        }

        private string CalculateExpression(string expression)
        {
            try
            {
                expression = expression.Replace(" ", "");
                if (expression.Contains("/0")) return "Error: Division by zero";

                var result = new DataTable().Compute(expression, null);
                return result?.ToString() ?? expression;
            }
            catch
            {
                return expression;
            }
        }

        private void UpdateWindowTitle()
        {
            string fileName = Path.GetFileName(path);
            this.Text = _isSaved ? $"Table Creator - {fileName}"
                                : $"Table Creator - {fileName} *";
        }

        private void SetSavePathItem_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                fbd.Description = "Выберите папку для сохранения файлов";
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    SavePathToJson("SavePath", fbd.SelectedPath);
                    MessageBox.Show($"Папка для сохранения установлена: {fbd.SelectedPath}",
                                  "Настройки",
                                  MessageBoxButtons.OK,
                                  MessageBoxIcon.Information);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var ofd = new OpenFileDialog())
            {
                ofd.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
                ofd.Title = "Выберите файл Excel";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    path = ofd.FileName;
                    SavePathToJson("Path", path);

                    try
                    {
                        // Сначала кэшируем доступные классы
                        CacheAvailableClasses(path);

                        // Затем загружаем их в комбобокс
                        LoadGroupedClasses();

                        _functions = new Functions(this);
                        _functions.LoadDataFromExcel(path, selectedEvent);
                        _functions.PopulateComboBox(comboBoxEvents);

                        // Если есть классы, выбираем первый
                        if (comboBoxClasses.Items.Count > 0)
                        {
                            comboBoxClasses.SelectedIndex = 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при загрузке файла: {ex.Message}",
                                        "Ошибка",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void buttonSaveFile_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(path))
                {
                    MessageBox.Show("Сначала откройте файл!", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string savePath = LoadPathFromJson("SavePath");
                if (string.IsNullOrEmpty(savePath))
                {
                    MessageBox.Show("Пожалуйста, укажите папку для сохранения.", "Ошибка",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string newFilePath = Path.Combine(savePath, "Измененный_" + Path.GetFileName(path));

                // Сохраняем изменения только в копию
                SaveChangesToCopy(newFilePath);

                _isSaved = true;
                UpdateWindowTitle();
            }
            catch (Exception ex)
            {
                _isSaved = false;
                UpdateWindowTitle();
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateExcelFile(string originalFilePath)
        {
            string savePath = LoadPathFromJson("SavePath");
            if (string.IsNullOrEmpty(savePath))
            {
                MessageBox.Show("Пожалуйста, укажите папку для сохранения.", "Ошибка",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string newFilePath = Path.Combine(savePath, "Измененный_" + Path.GetFileName(originalFilePath));

            try
            {
                // Сохраняем текущие изменения перед экспортом
                _functions.SaveCurrentChanges();

                // Копируем весь файл
                File.Copy(originalFilePath, newFilePath, true);

                // Открываем копию для сохранения изменений
                using (var package = new ExcelPackage(new FileInfo(newFilePath)))
                {
                    ExcelWorksheet sheet;
                    if (!string.IsNullOrEmpty(comboBoxClasses.SelectedItem?.ToString()) &&
                        !comboBoxClasses.SelectedItem.ToString().StartsWith("---"))
                    {
                        sheet = package.Workbook.Worksheets[comboBoxClasses.SelectedItem.ToString()];
                    }
                    else
                    {
                        sheet = package.Workbook.Worksheets[0];
                    }

                    if (sheet == null)
                    {
                        MessageBox.Show("Лист не найден.", "Ошибка",
                                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    int[] columns = GetColumnsForEvent(selectedEvent);

                    for (int i = 0; i < newDataGridView.Rows.Count; i++)
                    {
                        for (int j = 0; j < columns.Length; j++)
                        {
                            if (j < newDataGridView.Columns.Count - 2)
                            {
                                sheet.Cells[i + FirstDataRow, columns[j]].Value =
                                    newDataGridView.Rows[i].Cells[j + 2].Value;
                            }
                        }
                    }

                    package.Save();
                }

                _isSaved = true;
                UpdateWindowTitle();
                MessageBox.Show($"Изменения успешно сохранены в файл: {newFilePath}",
                              "Сохранение",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private string LoadPathFromJson(string key)
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string filePath = Path.Combine(appDataPath, "mydata.json");

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                JObject jsonObject = JObject.Parse(json);
                return jsonObject[key]?.ToString();
            }
            return null;
        }

        private void SavePathToJson(string name, string path)
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string filePath = Path.Combine(appDataPath, "mydata.json");

            JObject jsonObject = File.Exists(filePath)
                ? JObject.Parse(File.ReadAllText(filePath))
                : new JObject();

            if (!string.IsNullOrEmpty(path))
            {
                jsonObject[name] = path;
            }

            File.WriteAllText(filePath, jsonObject.ToString(Formatting.Indented));
        }

        public void UpdateDataGridViewWithScores(string selectedEvent)
        {
            if (_functions?.CurrentWorksheet == null)
                return;

            _programmaticChange = true;
            try
            {
                // Сохраняем текущие значения фамилий и имен
                var savedData = new List<Tuple<string, string>>();
                foreach (DataGridViewRow row in newDataGridView.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        savedData.Add(Tuple.Create(
                            row.Cells[0].Value?.ToString(),
                            row.Cells[1].Value?.ToString()));
                    }
                }

                // Очищаем все колонки кроме фамилии и имени
                while (newDataGridView.Columns.Count > 2)
                {
                    newDataGridView.Columns.RemoveAt(2);
                }

                // Добавляем колонки для текущего мероприятия
                var scoreColumnNames = GetScoreColumnNames(selectedEvent);
                foreach (var columnName in scoreColumnNames)
                {
                    newDataGridView.Columns.Add(columnName, columnName);
                }

                // Загружаем баллы для выбранного мероприятия
                var scores = _functions.GetScoresForEvent(selectedEvent);
                for (int i = 0; i < Math.Min(savedData.Count, scores.Count); i++)
                {
                    // Восстанавливаем фамилию и имя
                    newDataGridView.Rows[i].Cells[0].Value = savedData[i].Item1;
                    newDataGridView.Rows[i].Cells[1].Value = savedData[i].Item2;

                    // Заполняем баллы для текущего мероприятия
                    int[] columns = GetColumnsForEvent(selectedEvent);
                    for (int j = 0; j < columns.Length; j++)
                    {
                        if (j + 2 < newDataGridView.Columns.Count)
                        {
                            int excelCol = columns[j];
                            newDataGridView.Rows[i].Cells[j + 2].Value =
                                _functions.CurrentWorksheet.Cells[i + Form1.FirstDataRow, excelCol].Text;
                        }
                    }
                }
            }
            finally
            {
                _programmaticChange = false;
            }
        }

        public int[] GetColumnsForEvent(string eventName)
        {
            switch (eventName)
            {
                case "Ассамблея знаний":
                    return new int[] { 4, 5, 6, 7 };     // Столбцы D,E,F,G
                case "Предметные олимпиады":
                    return new int[] { 8, 9, 10 };       // Столбцы H,I,J
                case "Конференции НОУ":
                    return new int[] { 11, 12, 13 };     // Столбцы K,L,M
                case "Грани таланта":
                    return new int[] { 14 };             // Столбец N
                case "Прочие конкурсы":
                    return new int[] { 15, 16, 17 };     // Столбцы O,P,Q
                case "Балл классного руководителя":
                    return new int[] { 18 };             // Столбец R
                case "Соревнования":
                    return new int[] { 19, 20, 21 };     // Столбцы S,T,U
                default:
                    throw new Exception("Неизвестное мероприятие");
            }
        }

        private List<string> GetScoreColumnNames(string selectedEvent)
        {
            var worksheet = _functions.CurrentWorksheet;
            var scoreColumnNames = new List<string>();

            if (worksheet == null) return scoreColumnNames;

            switch (selectedEvent)
            {
                case "Ассамблея знаний":
                    for (int i = 0; i < 4; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + i].Text);
                    break;
                case "Предметные олимпиады":
                    for (int i = 0; i < 3; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 4 + i].Text);
                    break;
                case "Конференции НОУ":
                    for (int i = 0; i < 3; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 7 + i].Text);
                    break;
                case "Грани таланта":
                    scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 10].Text);
                    break;
                case "Прочие конкурсы":
                    for (int i = 0; i < 3; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 11 + i].Text);
                    break;
                case "Балл классного руководителя":
                    scoreColumnNames.Add(worksheet.Cells[2, FirstScoreColumn + 14].Text);
                    break;
                case "Соревнования":
                    for (int i = 0; i < 3; i++)
                        scoreColumnNames.Add(worksheet.Cells[3, FirstScoreColumn + 15 + i].Text);
                    break;
            }

            return scoreColumnNames;
        }

        public bool WorksheetExists(ExcelPackage package, string name)
        {
            if (package == null || string.IsNullOrEmpty(name))
                return false;

            string normalizedSearch = name.Replace(" ", "").ToUpper();
            return package.Workbook.Worksheets.Any(ws =>
                ws.Name.Replace(" ", "").ToUpper() == normalizedSearch);
        }

        private void LoadGroupedClasses()
        {
            comboBoxClasses.Items.Clear();

            if (_availableClassesCache == null || _availableClassesCache.Count == 0)
            {
                MessageBox.Show("Не найдено ни одного класса в формате '5А', '6Б' и т.д.",
                               "Информация",
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Information);
                return;
            }

            // Сортируем классы по возрастанию (5,6,7...11)
            var sortedGrades = _availableClassesCache.Keys.OrderBy(g => int.Parse(g));

            foreach (var grade in sortedGrades)
            {
                // Сортируем буквы в алфавитном порядке
                var sortedClasses = _availableClassesCache[grade]
                    .OrderBy(c => c[1].ToString(), StringComparer.Ordinal);

                // Добавляем разделитель с номером класса
                comboBoxClasses.Items.Add($"--- {grade} класс ---");

                // Добавляем сами классы
                foreach (var className in sortedClasses)
                {
                    comboBoxClasses.Items.Add(className);
                }
            }
        }

        private void CacheAvailableClasses(string filePath)
        {
            _availableClassesCache = new Dictionary<string, List<string>>();

            try
            {
                using (var package = new ExcelPackage(new FileInfo(filePath)))
                {
                    foreach (var worksheet in package.Workbook.Worksheets)
                    {
                        string normalizedName = worksheet.Name.Replace(" ", "").ToUpper();

                        // Пропускаем пустые листы
                        if (worksheet.Dimension == null) continue;

                        // Проверяем формат: цифры (5-11) + буква (А-Т)
                        if (normalizedName.Length >= 2 &&
                            AvailableLetters.Contains(normalizedName.Last().ToString()))
                        {
                            string gradePart = normalizedName.Substring(0, normalizedName.Length - 1);
                            if (int.TryParse(gradePart, out int grade) && grade >= 5 && grade <= 11)
                            {
                                string gradeStr = grade.ToString();
                                string className = worksheet.Name; // Сохраняем оригинальное имя листа

                                if (!_availableClassesCache.ContainsKey(gradeStr))
                                {
                                    _availableClassesCache[gradeStr] = new List<string>();
                                }

                                if (!_availableClassesCache[gradeStr].Contains(className))
                                {
                                    _availableClassesCache[gradeStr].Add(className);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при анализе листов: {ex.Message}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void LoadClassData(string className)
        {
            try
            {
                if (string.IsNullOrEmpty(path))
                {
                    MessageBox.Show("Сначала откройте файл!", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Загружаем данные для выбранного класса
                _functions.LoadDataFromExcel(path, selectedEvent, className);

                // Если мероприятие выбрано, обновляем DataGridView с баллами
                if (!string.IsNullOrEmpty(selectedEvent))
                {
                    UpdateDataGridViewWithScores(selectedEvent);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных класса: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AboutItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Table Creator\nВерсия 1.0\n\nПрограмма для работы с таблицами рейтингов учащихся.",
                           "О программе",
                           MessageBoxButtons.OK,
                           MessageBoxIcon.Information);
        }

        private void InitializeMenuStrip()
        {
            MenuStrip menuStrip = new MenuStrip();

            // Меню "Файл"
            ToolStripMenuItem fileMenu = new ToolStripMenuItem("Файл");

            // Подменю "Настройки"
            ToolStripMenuItem settingsMenu = new ToolStripMenuItem("Настройки");
            ToolStripMenuItem setSavePathItem = new ToolStripMenuItem("Указать папку для сохранения");
            setSavePathItem.Click += SetSavePathItem_Click;
            settingsMenu.DropDownItems.Add(setSavePathItem);

            fileMenu.DropDownItems.Add(settingsMenu);
            fileMenu.DropDownItems.Add(new ToolStripSeparator());

            // Выход
            ToolStripMenuItem exitItem = new ToolStripMenuItem("Выход");
            exitItem.Click += (s, e) => this.Close();
            fileMenu.DropDownItems.Add(exitItem);

            menuStrip.Items.Add(fileMenu);

            // Меню "Помощь"
            ToolStripMenuItem helpMenu = new ToolStripMenuItem("Помощь");
            ToolStripMenuItem aboutItem = new ToolStripMenuItem("О программе");
            aboutItem.Click += AboutItem_Click;
            helpMenu.DropDownItems.Add(aboutItem);

            menuStrip.Items.Add(helpMenu);

            this.Controls.Add(menuStrip);
            this.MainMenuStrip = menuStrip;
        }
    }

    public class CustomCloseDialog : Form
    {
        public CustomCloseDialog()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Подтверждение закрытия";
            this.Size = new Size(350, 180);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.ControlBox = false;

            var message = new Label
            {
                Text = "Вы не сохранили файл. Выберите действие:",
                Location = new Point(20, 20),
                AutoSize = true
            };

            var saveButton = new Button
            {
                Text = "Сохранить и выйти",
                DialogResult = DialogResult.Yes,
                Location = new Point(20, 60),
                Size = new Size(120, 30)
            };

            var noSaveButton = new Button
            {
                Text = "Выйти без сохранения",
                DialogResult = DialogResult.No,
                Location = new Point(160, 60),
                Size = new Size(150, 30)
            };

            var cancelButton = new Button
            {
                Text = "Отменить",
                DialogResult = DialogResult.Cancel,
                Location = new Point(20, 100),
                Size = new Size(290, 30)
            };

            this.Controls.Add(message);
            this.Controls.Add(saveButton);
            this.Controls.Add(noSaveButton);
            this.Controls.Add(cancelButton);
        }
    }
}